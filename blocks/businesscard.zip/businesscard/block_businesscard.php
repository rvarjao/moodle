<?php

class block_businesscard extends block_base {
    public function init() {
        $this->title = get_string('businesscard', 'block_businesscard');
    }

    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = 'Hello, World!';
        $this->content->footer = '';

        return $this->content;
    }
}
