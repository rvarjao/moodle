<?php

$string['pluginname'] = 'Business card';
$string['businesscard'] = 'Business card';
