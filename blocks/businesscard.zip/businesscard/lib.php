<?php
/**
 * Version details
 *
 * @package    block_businesscard
 * @copyright  2024 Ricardo Varjao
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

function local_message_before_footer() {
    echo ('<h1>Hello World</h1>');
}
